/**
 * 
 */
/**
 * 
 */
module PJ {
	requires java.desktop;
}